<?php

// module name
$HmvcMenu["award"] = array(
    //set icon
    "icon"           => "<i class='fa fa-trophy' aria-hidden='true'></i>

", 
    
 //group level name
    "new_award" => array(
        //menu name
       
            "controller" => "Award_controller",
            "method"     => "create_award",
            "permission" => "create"
        
    ), 
    
    
);
   

 