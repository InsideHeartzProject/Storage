<?php get_header(); ?>

<?php get_template_part('inc/page-title'); ?>

<div class="content">
	<div class="content-inner group">
	
	</div>
</div><!--/.content-->

<div id="move-sidebar-content"></div>

<?php get_footer(); ?>